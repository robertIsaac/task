<?php
/**
 * Created by PhpStorm.
 * User: rober
 * Date: 25-May-18
 * Time: 12:32 PM
 */
//var_dump(__LINE__);
define('TYPES' , [
    'text',
    'select',
    'checkbox',
    'date',
    'time',
    'datetime-local',
    'number',
]);